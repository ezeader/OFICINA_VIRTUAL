import {enqueue} from '../lib/queue.js';
import {equal,validSignature,inbound} from '../lib/core.js';
export async function GET(request){
 const q=new URL(request.url).searchParams;
 if(!process.env.META_VERIFY_TOKEN)return new Response('Not configured',{status:503});
 if(q.get('hub.mode')==='subscribe'&&equal(q.get('hub.verify_token'),process.env.META_VERIFY_TOKEN))return new Response(q.get('hub.challenge')||'',{headers:{'Content-Type':'text/plain'}});
 return new Response('Forbidden',{status:403});
}
export async function POST(request){
 if(!process.env.META_APP_SECRET)return new Response('Not configured',{status:503});
 const raw=Buffer.from(await request.arrayBuffer());
 if(raw.length>1000000)return new Response('Too large',{status:413});
 if(!validSignature(raw,request.headers.get('x-hub-signature-256'),process.env.META_APP_SECRET))return new Response('Forbidden',{status:403});
 let payload;try{payload=JSON.parse(raw.toString('utf8'));}catch{return new Response('Bad JSON',{status:400});}
 if((process.env.BOT_MODE||'off')==='off')return new Response('EVENT_RECEIVED');
 try{
  const events=inbound(payload,process.env.INSTAGRAM_ACCOUNT_ID);
  // Limited pilot: no unbounded fan-out. Meta may retry a rejected large batch.
  if(events.length>5)return new Response('Pilot batch limit',{status:503});
  await Promise.all(events.map(enqueue));
  return new Response('EVENT_RECEIVED');
 }catch{return new Response('Temporary failure',{status:503});}
}
