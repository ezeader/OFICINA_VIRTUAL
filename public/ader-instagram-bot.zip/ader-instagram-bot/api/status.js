import {equal} from '../lib/core.js';
export function GET(request){
 if(!equal(request.headers.get('authorization'),process.env.ADMIN_TOKEN?'Bearer '+process.env.ADMIN_TOKEN:null))return new Response('Unauthorized',{status:401});
 const names=['META_VERIFY_TOKEN','META_APP_SECRET','INSTAGRAM_ACCOUNT_ID','INSTAGRAM_ACCESS_TOKEN','META_API_VERSION','GROQ_API_KEY','QSTASH_TOKEN','QUEUE_WORKER_TOKEN','UPSTASH_REDIS_REST_URL','UPSTASH_REDIS_REST_TOKEN'];
 return Response.json({mode:process.env.BOT_MODE||'off',configured:Object.fromEntries(names.map(k=>[k,Boolean(process.env[k])]))},{headers:{'Cache-Control':'no-store'}});
}
