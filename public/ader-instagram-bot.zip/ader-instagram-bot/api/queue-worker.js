import {equal} from '../lib/core.js';
import {drain} from '../lib/queue.js';
export async function POST(request){
 const secret=process.env.QUEUE_WORKER_TOKEN;
 if(!secret||secret.length<32||!equal(request.headers.get('authorization'),`Bearer ${secret}`))return new Response('Unauthorized',{status:401});
 let job;try{job=await request.json();}catch{return new Response('Bad JSON',{status:400});}
 if(!/^\d+$/.test(job?.sender||'')||!['draft','test','live'].includes(job?.mode))return new Response('Bad job',{status:400});
 try{await drain(job.sender,job.mode);return new Response('OK');}catch{return new Response('Retry later',{status:503});}
}
