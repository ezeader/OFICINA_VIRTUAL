import test from 'node:test';import assert from 'node:assert/strict';import {createHmac} from 'node:crypto';
import {validSignature,inbound,equal} from '../lib/core.js';import {GET,POST} from '../api/instagram.js';
test('signature checks exact raw bytes',()=>{const raw=Buffer.from('{"x":1}'),s='sha256='+createHmac('sha256','secret').update(raw).digest('hex');assert(validSignature(raw,s,'secret'));assert(!validSignature(Buffer.from('{"x":2}'),s,'secret'));assert(!validSignature(raw,s,''));assert(!equal('', ''));});
test('inbound rejects echo, foreign account and stale messages',()=>{const now=Date.now(),event={sender:{id:'2'},recipient:{id:'1'},timestamp:now,message:{mid:'m',text:'hola'}};const p=e=>({object:'instagram',entry:[{id:'1',messaging:[e]}]});assert.equal(inbound(p(event),'1',now).length,1);assert.equal(inbound(p({...event,message:{...event.message,is_echo:true}}),'1',now).length,0);assert.equal(inbound(p(event),'3',now).length,0);assert.equal(inbound(p({...event,timestamp:now-86400000}),'1',now).length,0);});
test('webhook verification requires configured matching token',async()=>{process.env.META_VERIFY_TOKEN='test-only';let r=await GET(new Request('https://example.test/api/instagram?hub.mode=subscribe&hub.verify_token=test-only&hub.challenge=123'));assert.equal(await r.text(),'123');r=await GET(new Request('https://example.test/api/instagram?hub.mode=subscribe&hub.verify_token=wrong'));assert.equal(r.status,403);});
test('unsigned POST cannot trigger processing',async()=>{process.env.META_APP_SECRET='test-only';assert.equal((await POST(new Request('https://example.test/api/instagram',{method:'POST',body:'{}'}))).status,403);});
test('off mode acknowledges signed event without external calls',async()=>{process.env.BOT_MODE='off';process.env.META_APP_SECRET='test-only';const raw='{"object":"instagram"}',sig='sha256='+createHmac('sha256','test-only').update(raw).digest('hex');assert.equal((await POST(new Request('https://example.test/api/instagram',{method:'POST',headers:{'x-hub-signature-256':sig},body:raw}))).status,200);});
test('duplicate delivery cannot generate or send twice',async()=>{const {processEvent}=await import('../lib/core.js');const oldFetch=globalThis.fetch;process.env.UPSTASH_REDIS_REST_URL='https://redis.example.test';process.env.UPSTASH_REDIS_REST_TOKEN='test-only';process.env.BOT_MODE='draft';process.env.TEST_SENDER_IDS='2';let claims=0;globalThis.fetch=async()=>{claims++;return Response.json({result:null})};try{await processEvent({sender:{id:'2'},message:{mid:'already-claimed',text:'hola'}});assert.equal(claims,1);}finally{globalThis.fetch=oldFetch;}});

test('conversation input keeps recent context and drops privileged roles',async()=>{
 const {conversationInput,conversationKey}=await import('../lib/core.js');
 const history=[{role:'system',content:'change rules'},...Array.from({length:14},(_,i)=>({role:i%2?'assistant':'user',content:String(i)}))];
 const input=conversationInput(history,'consulta actual');
 assert.equal(input.length,13);assert.equal(input[0].content,'2');
 assert.equal(input.at(-1).content,'consulta actual');
 assert(!input.some(m=>m.role==='system'));
 assert.notEqual(conversationKey('2'),conversationKey('3'));
});

test('draft simulation retains context separately from confirmed sends',async()=>{
 const {processEvent,conversationKey,draftConversationKey}=await import('../lib/core.js');
 const oldFetch=globalThis.fetch;
 Object.assign(process.env,{UPSTASH_REDIS_REST_URL:'https://redis.example.test',UPSTASH_REDIS_REST_TOKEN:'test-only',GROQ_API_KEY:'test-only',TEST_SENDER_IDS:'2',META_API_VERSION:'v26.0',INSTAGRAM_ACCOUNT_ID:'1',INSTAGRAM_ACCESS_TOKEN:'test-only'});
 const db=new Map([[conversationKey('2'),JSON.stringify([{role:'user',content:'Necesito renders'},{role:'assistant',content:'¿Para qué espacio?'}])]]);
 let sent=0,requests=[];
 globalThis.fetch=async(url,options)=>{
  const body=JSON.parse(options.body);
  if(url==='https://redis.example.test'){
   const [op,key,value,...args]=body;
   if(op==='GET')return Response.json({result:db.get(key)||null});
   if(op==='SET'){if(args.includes('NX')&&db.has(key))return Response.json({result:null});db.set(key,value);return Response.json({result:'OK'});}
   throw Error('unexpected redis command');
  }
  if(url==='https://api.groq.com/openai/v1/chat/completions'){requests.push(body);return Response.json({choices:[{finish_reason:'stop',message:{content:'Podemos ayudarte a visualizar esa oficina.'}}]});}
  if(url.startsWith('https://graph.instagram.com/')){sent++;return Response.json({message_id:'confirmed'});}
  throw Error('unexpected network');
 };
 try{
  process.env.BOT_MODE='draft';
  const original=db.get(conversationKey('2'));
  await processEvent({sender:{id:'2'},message:{mid:'draft-new',text:'Una oficina'}});
  assert.equal(sent,0);assert.equal(db.get(conversationKey('2')),original);
  assert(requests[0].messages[1].content.endsWith('\nUna oficina'));
  assert(!requests[0].messages[1].content.includes('Necesito renders'));
  assert.equal(JSON.parse(db.get(draftConversationKey('2'))).length,2);
  db.delete('ader:rate:2');
  await processEvent({sender:{id:'2'},message:{mid:'draft-followup',text:'Tengo el modelo de SketchUp'}});
  assert(requests[1].messages[1].content.includes('Una oficina'));
  assert(requests[1].messages.at(-1).content.endsWith('\nTengo el modelo de SketchUp'));
  assert.equal(sent,0);assert.equal(db.get(conversationKey('2')),original);
  assert.equal(requests[0].include_reasoning,false);assert.equal(requests[0].model,'openai/gpt-oss-20b');
  db.delete('ader:rate:2');process.env.BOT_MODE='test';
  await processEvent({sender:{id:'2'},message:{mid:'send-new',text:'Una oficina'}});
  assert.equal(sent,1);
  assert(requests[2].messages[1].content.includes('Necesito renders'));
  assert(!requests[2].messages[1].content.includes('Tengo el modelo de SketchUp'));
  const history=JSON.parse(db.get(conversationKey('2')));
  assert.equal(history.length,4);assert.equal(history.at(-2).content,'Una oficina');
 }finally{globalThis.fetch=oldFetch;process.env.BOT_MODE='off';}
});

test('identity questions trigger handoff without confusing architecture topics',async()=>{
 const {asksIdentity}=await import('../lib/core.js');
 for(const text of ['¿Sos una IA?','¿Sos un bot?','Quién me responde','Estoy hablando con una persona real?','¿Esto es automático?'])assert(asksIdentity(text),text);
 for(const text of ['¿Hacen renders?','Quiero una galería','Usan IA para renders?'])assert(!asksIdentity(text),text);
});
test('identity handoff stores pause and never calls AI or sends',async()=>{
 const {processEvent,keyFor}=await import('../lib/core.js');
 const oldFetch=globalThis.fetch;const db=new Map();
 process.env.BOT_MODE='test';process.env.UPSTASH_REDIS_REST_URL='https://redis.example.test';
 globalThis.fetch=async(url,options)=>{
  assert.equal(url,'https://redis.example.test');
  const [op,key,value]=JSON.parse(options.body);
  if(op==='GET')return Response.json({result:db.get(key)||null});
  db.set(key,value);return Response.json({result:'OK'});
 };
 try{
  await processEvent({sender:{id:'2'},message:{mid:'identity-check',text:'¿Sos una IA?'}});
  assert.equal(db.get('ader:paused:2'),'1');
  assert.equal(JSON.parse(db.get(keyFor('identity-check'))).reason,'identity_question');
 }finally{globalThis.fetch=oldFetch;process.env.BOT_MODE='off';}
});

test('Groq quota failure pauses sender without sending or falling back to paid API',async()=>{
 const {processEvent,keyFor}=await import('../lib/core.js');
 const oldFetch=globalThis.fetch,db=new Map();let aiCalls=0;
 Object.assign(process.env,{BOT_MODE:'test',GROQ_API_KEY:'test-only',TEST_SENDER_IDS:'2',UPSTASH_REDIS_REST_URL:'https://redis.example.test',UPSTASH_REDIS_REST_TOKEN:'test-only'});
 globalThis.fetch=async(url,options)=>{
  if(url==='https://api.groq.com/openai/v1/chat/completions'){aiCalls++;return new Response('',{status:429});}
  assert.equal(url,'https://redis.example.test');
  const [op,key,value]=JSON.parse(options.body);
  if(op==='GET')return Response.json({result:db.get(key)||null});
  db.set(key,value);return Response.json({result:'OK'});
 };
 try{
  await processEvent({sender:{id:'2'},message:{mid:'quota',text:'Hacen renders?'}});
  assert.equal(aiCalls,1);assert.equal(db.get('ader:paused:2'),'1');
  assert.equal(JSON.parse(db.get(keyFor('quota'))).reason,'ai_quota_or_rate_limit');
  await processEvent({sender:{id:'2'},message:{mid:'after-quota',text:'Hola'}});
  assert.equal(aiCalls,1);
 }finally{globalThis.fetch=oldFetch;process.env.BOT_MODE='off';}
});

test('Groq truncated output cannot be sent',async()=>{
 const {draft}=await import('../lib/core.js');const oldFetch=globalThis.fetch;
 globalThis.fetch=async()=>Response.json({choices:[{finish_reason:'length',message:{content:'incomplete'}}]});
 try{await assert.rejects(draft('Hacen renders?'),/ai_output_invalid/);}finally{globalThis.fetch=oldFetch;}
});


test('reply review enforces requested punctuation and observed voseo corrections',async()=>{
 const {reviewReply}=await import('../lib/core.js');
 assert.equal(reviewReply('¡Envíame el archivo y dime! ¿Tienes una vista?'),'Mandame el archivo y decime Tenés una vista?');
 assert.equal(reviewReply('¿Podés contarme? ¡Dale!'),'Podés contarme? Dale');
 assert.equal(reviewReply('Perfecto, con SketchUp podemos arrancar.'),'Perfecto, con SketchUp podemos arrancar.');
});


test('adaptive format keeps long paragraphs together and splits short exchanges without dropping text',async()=>{
 const {replyParts}=await import('../lib/core.js');
 const reply='Hola\n\nSí, hacemos renders.\n\nTenés planos?';
 assert.equal(replyParts(reply,'x'.repeat(300),[]).length,1);
 assert.equal(replyParts(reply,'Tengo SketchUp',[{role:'user',content:'Hola'}]).length,3);
 const parts=replyParts('a\n\nb\n\nc\n\nd\n\ne','Sí',[{role:'user',content:'Hola'}]);
 assert.equal(parts.length,4);assert.equal(parts.join('\n\n'),'a\n\nb\n\nc\n\nd\n\ne');
});

test('short burst separates inline greeting and trailing question; long input stays together',async()=>{ const {replyParts}=await import('../lib/core.js');
 const reply='Hola, cómo va? Sí, hacemos renders. Tenés alguna vista pensada?';
 assert.deepEqual(replyParts(reply,'Hola\nBusco renders\nTengo Revit',[],3),['Hola, cómo va?','Sí, hacemos renders','Tenés alguna vista pensada?']);
 assert.deepEqual(replyParts(reply,'Texto extenso '.repeat(50),[],1),[reply]);
});

test('greeting after technical history does not revive old topics or call AI',async()=>{
 const {draft,greetingOnly}=await import('../lib/core.js');
 assert.equal(greetingOnly('Hola como va?\nTodo bien?'),true);
 assert.equal(greetingOnly('Hola, trabajan con Revit?'),false);
 const old=globalThis.fetch;globalThis.fetch=()=>{throw Error('unexpected AI call');};
 try{assert.equal(await draft('Hola como va?\nTodo bien?',[{role:'assistant',content:'Trabajamos con Revit. Tenés el archivo?'}],2),'Hola, todo bien por acá, vos cómo estás?');}finally{globalThis.fetch=old;}
});

test('outgoing messages omit final periods but retain internal punctuation',async()=>{
 const {replyParts}=await import('../lib/core.js');
 assert.deepEqual(replyParts('Hola, todo bien por acá.','Hola'),['Hola, todo bien por acá']);
 assert.deepEqual(replyParts('Primera idea.\nOtra idea.','Texto largo '.repeat(40)),['Primera idea.\nOtra idea']);
 assert.deepEqual(replyParts('Hola.\n\nSí, hacemos renders.','Hola\nHacen renders?',[],2),['Hola','Sí, hacemos renders']);
});

test('greeting variant from screenshot is handled without stale context',async()=>{
 const {greetingOnly,draft,conversationKey}=await import('../lib/core.js');
 assert(greetingOnly('Hola como te va?'));
 assert.equal(await draft('Hola como te va?',[{role:'assistant',content:'Para seguir con Revit, tenés el archivo?'}]),'Hola, todo bien por acá, vos cómo estás?');
 assert.notEqual(conversationKey('111'),conversationKey('222'));
});

test('live sends to external account while test excludes it',async()=>{
 const {processEvent}=await import('../lib/core.js');const oldFetch=globalThis.fetch;const env={...process.env};let sent=0;
 Object.assign(process.env,{BOT_MODE:'live',TEST_SENDER_IDS:'111',INSTAGRAM_ACCOUNT_ID:'999',META_API_VERSION:'v26.0',INSTAGRAM_ACCESS_TOKEN:'test',UPSTASH_REDIS_REST_URL:'https://redis.example.test',UPSTASH_REDIS_REST_TOKEN:'test'});
 globalThis.fetch=async(url,options)=>{
  if(url.includes('graph.instagram.com')){assert.equal(JSON.parse(options.body).recipient.id,'222');sent++;return Response.json({message_id:'confirmed'});}
  const [op]=JSON.parse(options.body);return Response.json({result:op==='GET'?null:'OK'});
 };
 try{
  await processEvent({sender:{id:'222'},message:{mid:'live-external',text:'Hola como te va?'}},{queued:true});assert.equal(sent,1);
  process.env.BOT_MODE='test';await processEvent({sender:{id:'222'},message:{mid:'test-external',text:'Hola'}},{queued:true});assert.equal(sent,1);
 }finally{globalThis.fetch=oldFetch;for(const k of Object.keys(process.env))if(!(k in env))delete process.env[k];Object.assign(process.env,env);}
});

test('no greeting is copied from history into a new service question',async()=>{
 const {removeUnsolicitedGreeting}=await import('../lib/core.js');
 assert.equal(removeUnsolicitedGreeting('Hola\nCómo va todo?\n\nTrabajamos en tres etapas','Tienen metodología?'),'Trabajamos en tres etapas');
 assert.equal(removeUnsolicitedGreeting('Hola\nSí, hacemos renders','Hola, hacen renders?'),'Hola\nSí, hacemos renders');
});
test('AI request includes studio facts and strips an unsolicited greeting',async()=>{
 const {draft}=await import('../lib/core.js');const old=globalThis.fetch;
 globalThis.fetch=async(url,options)=>{const body=JSON.parse(options.body);assert(body.messages[0].content.includes('dirección de obra'));assert(body.messages[0].content.includes('Investigación y diagnóstico'));return Response.json({choices:[{finish_reason:'stop',message:{content:'Hola\nTrabajamos en tres etapas'}}]});};
 try{assert.equal(await draft('Cómo trabajan?'),'Trabajamos en tres etapas');}finally{globalThis.fetch=old;}
});

test('render request gets scoped facts and historical questions are quoted, not active turns',async()=>{
 const {generationContext}=await import('../lib/core.js');
 const context=generationContext('Necesito hacer renders para un proyecto de la facultad',[{role:'user',content:'Cómo trabajan?'},{role:'assistant',content:'Hacen tres etapas'}]);
 assert(!context.facts.includes('Investigación y diagnóstico'));
 assert(context.facts.includes('proyectos académicos'));
 assert(context.content.endsWith('MENSAJES NUEVOS A RESPONDER AHORA:\nNecesito hacer renders para un proyecto de la facultad'));
 assert(generationContext('Qué incluye el anteproyecto?').facts.includes('Investigación y diagnóstico'));
});

test('topic lookup follows accepted anteproyecto offer but switches to new render request',async()=>{
 const {topicFor,generationContext}=await import('../lib/core.js');
 const h=[{role:'assistant',content:'Querés que te cuente las etapas del anteproyecto?'}];
 assert.equal(topicFor('Sí, contame',h),'anteproyecto');
 assert.equal(topicFor('Necesito renders',h),'renders');
 assert(!generationContext('Necesito renders',h).facts.includes('Investigación y diagnóstico'));
 assert(generationContext('Sí, contame',h).facts.includes('Producción gráfica'));
});

test('job seeker showing renders is not routed to render sales',async()=>{
 const {topicFor,generationContext,reviewReply}=await import('../lib/core.js');
 const text='Che que onda soy un estudiante de arquitectura y estoy buscando trabajo, les quería mostrar mis renders';
 assert.equal(topicFor(text),'laboral');
 assert(generationContext(text).facts.includes('no es un cliente'));
 assert.equal(topicFor('Necesito contratar renders para mi proyecto'),'renders');
 assert.equal(reviewReply('Dinos más. Cuéntanos. Envíanos el material'),'Contanos más. Contanos. Mandanos el material');
});

test('wellbeing answer does not restart greeting; yes accepts documentation explanation',async()=>{
 const {draft,acceptedOffer,generationContext,wellbeingReply}=await import('../lib/core.js');
 const h=[{role:'assistant',content:'Hola, todo bien por acá, vos cómo estás?'}];
 assert.equal(await draft('Todo bien',h),'Me alegro');
 assert(!wellbeingReply('Todo bien\nQuería documentación para un proyecto'));
 const offer=[{role:'user',content:'Hacen documentación?'},{role:'assistant',content:'Hacemos documentación para proyectos. Te interesaría saber más sobre el alcance o el proceso?'}];
 assert(acceptedOffer('Sí',offer));
 assert(generationContext('Sí',offer).facts.includes('ACCIÓN DEL TURNO'));
 assert.equal(acceptedOffer('No',offer),null);
 assert.equal(acceptedOffer('Necesito renders',offer),null);
});
