import test from 'node:test';import assert from 'node:assert/strict';
import {drain,enqueue,qstashBase} from '../lib/queue.js';
import {POST} from '../api/queue-worker.js';
test('worker refuses unauthenticated jobs',async()=>{
 process.env.QUEUE_WORKER_TOKEN='x'.repeat(32);
 assert.equal((await POST(new Request('https://example.test',{method:'POST',body:'{}'}))).status,401);
});
test('queue combines pending messages into one generation and repeated jobs do not regenerate',async()=>{
 const old=globalThis.fetch;const db=new Map();let pending=[
 {sender:{id:'2'},timestamp:Date.now(),message:{mid:'a',text:'Necesito renders de un living'}},
 {sender:{id:'2'},timestamp:Date.now(),message:{mid:'b',text:'Tengo SketchUp'}}
 ].map(JSON.stringify);let ai=0;
 Object.assign(process.env,{BOT_MODE:'draft',TEST_SENDER_IDS:'2',GROQ_API_KEY:'test',UPSTASH_REDIS_REST_URL:'https://redis.example.test',UPSTASH_REDIS_REST_TOKEN:'test'});
 globalThis.fetch=async(url,options)=>{
  const body=JSON.parse(options.body);
  if(url.includes('api.groq.com')){ai++;assert(body.messages.at(-1).content.includes('living\nTengo SketchUp'));return Response.json({choices:[{finish_reason:'stop',message:{content:'Podemos partir del modelo.\n\nTenés alguna vista?'}}]});}
  assert.equal(url,'https://redis.example.test');const [op,key,value,...args]=body;
  if(op==='GET')return Response.json({result:db.get(key)||null});
  if(op==='SET'){if(args.includes('NX')&&db.has(key))return Response.json({result:null});db.set(key,value);return Response.json({result:'OK'});}
  if(op==='DEL'){db.delete(key);return Response.json({result:1});}
  if(op==='ZRANGE')return Response.json({result:pending.length?[pending[0],Date.now()-16000]:[]});
  if(op==='EVAL'){
   if(key.includes("ZRANGE")){const result=pending;pending=[];return Response.json({result});}
   db.delete(body[3]);return Response.json({result:1});
  }
  throw Error('unexpected command');
 };
 try{await drain('2','draft');await drain('2','draft');assert.equal(ai,1);}finally{globalThis.fetch=old;process.env.BOT_MODE='off';}
});
test('enqueue schedules delayed authenticated callback without text in job',async()=>{
 const old=globalThis.fetch;Object.assign(process.env,{BOT_MODE:'draft',TEST_SENDER_IDS:'2',QSTASH_TOKEN:'test',QUEUE_WORKER_TOKEN:'x'.repeat(32)});
 let scheduled=0;
 globalThis.fetch=async(url,options)=>{
  if(url.includes('qstash')){scheduled++;assert.equal(options.headers['Upstash-Delay'],'15s');assert.equal(options.headers['Upstash-Forward-Authorization'],'Bearer '+'x'.repeat(32));assert.deepEqual(JSON.parse(options.body),{sender:'2',mode:'draft'});return Response.json({messageId:'job'});}
  return Response.json({result:1});
 };
 try{await enqueue({sender:{id:'2'},timestamp:Date.now(),message:{mid:'new',text:'Hola'}});assert.equal(scheduled,1);}finally{globalThis.fetch=old;process.env.BOT_MODE='off';}
});

test('regional queue URL rejects foreign hosts before credentials can be sent',()=>{
 const old=process.env.QSTASH_URL;
 try{
 process.env.QSTASH_URL='https://qstash-eu-central-1.upstash.io/';
 assert.equal(qstashBase(),'https://qstash-eu-central-1.upstash.io');
 process.env.QSTASH_URL='https://example.com';assert.throws(qstashBase);
 }finally{if(old===undefined)delete process.env.QSTASH_URL;else process.env.QSTASH_URL=old;}
});
