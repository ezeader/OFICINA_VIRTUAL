# Ader Studio · Bot de Instagram — piloto 0.3

Actualización 19/10/2026: piloto Groq preparado localmente, todavía NO instalado ni probado con credenciales reales. Meta figura Publicada y se observó un POST /api/instagram con HTTP 200 a las 21:07. No confirma una respuesta de IA. Sin secretos incluidos.

## Actualizar el proyecto existente
1. Mantener BOT_MODE=off en Production.
2. Guardar GROQ_API_KEY como secreto de Production. Modelo por defecto: openai/gpt-oss-20b servido por Groq; no llama a la API de OpenAI ni usa OPENAI_API_KEY.
3. Descomprimir el ZIP nuevo en una carpeta separada. Arrastrar la carpeta completa ader-instagram-bot al proyecto existente en Vercel. Comprobar 14 archivos y el proyecto ader-instagram-bot antes de Deploy to Production.
4. Esperar Ready. Revisar /privacidad.html: debe mencionar Groq.
5. Configurar la prueba gradual indicada abajo; no activar test hasta revisar borradores y autorizar un ID propio.

## Variables

Consultar .env.example para todos los nombres. Se incluyen nombres y valores públicos, nunca claves reales.

Para verificar el webhook bastan META_VERIFY_TOKEN (valor aleatorio largo elegido por el titular) y META_APP_SECRET (secreto de la app de Instagram correspondiente, NO el token de acceso). La dirección de callback será https://TU-DOMINIO/api/instagram. En Meta, «Token de verificación» debe coincidir exactamente con META_VERIFY_TOKEN.

Para el piloto con IA se requieren además:
- INSTAGRAM_ACCOUNT_ID: 17841477708800210, observado en el panel de @estudio.ader. Confirmarlo antes de activar.
- INSTAGRAM_ACCESS_TOKEN: token de esa cuenta, con permisos de mensajería.
- META_API_VERSION: versión habilitada por Meta para la app, por ejemplo el formato vNN.N; no dejar ese ejemplo literal.
- GROQ_API_KEY: clave de la cuenta Free de Groq. GROQ_MODEL es opcional y usa openai/gpt-oss-20b por defecto. Esta integración no cambia tu plan ni activa facturación. Las cuotas dependen de tu cuenta; no se garantiza gratuidad ilimitada ni disponibilidad. Mantener plan Free sin método de pago. Un error o cuota agotada pausa al remitente 24 h y registra human_required; no hay notificación al teléfono ni reintento automático. No cambiar el modelo sin verificar compatibilidad con reasoning_effort e include_reasoning.
- UPSTASH_REDIS_REST_URL y UPSTASH_REDIS_REST_TOKEN: almacenamiento Redis persistente, requerido para deduplicación y estados. Crear/conectar desde la integración disponible en Vercel o Upstash; revisar plan antes de contratar.
- ADMIN_TOKEN: secreto aleatorio para GET /api/status, enviado por Authorization: Bearer. No enviarlo en la URL. La respuesta solo informa presencia de variables, no sus valores.
- TEST_SENDER_IDS: IDs numéricos de remitentes de prueba, separados por coma. No son nombres de usuario. Un primer evento firmado en modo draft queda registrado en Redis con su sender, sin responder a una cuenta no autorizada.

## Prueba gradual

1. off: permite validación de Meta; no almacena ni procesa mensajes.
2. draft: solo genera borradores para los IDs de prueba autorizados. Estados consultables en Redis, claves ader:message:*. No envía mensajes.
3. test: envía respuestas únicamente a esos mismos IDs autorizados. Cambiar a test solo después de revisar los borradores. No existe modo de respuesta a toda la comunidad en esta entrega.

Las consultas sobre presupuestos, reclamos, personas o temas técnicos se marcan human_required; el remitente se pausa por 24 horas. Esto NO notifica a Ezequiel: debe revisar Instagram y los estados de Redis. Los archivos, audios e imágenes se marcan para atención humana. Solo texto está implementado. No hay comentarios, WhatsApp ni lectura de proyectos privados.

El contenido autorizado al modelo está en lib/core.js; es deliberadamente breve y no incluye datos de clientes. Revisar esos textos con el titular antes de activar. El modelo no usa herramientas ni navega. Los borradores pueden equivocarse y requieren revisión durante el piloto.

## Operación y límites del piloto

- Verifica HMAC SHA-256 del cuerpo original antes de procesar.
- Rechaza eventos de otras cuentas, ecos y mensajes de más de 23 horas.
- Redis guarda estados hasta 7 días y pausas hasta 24 horas. Puede almacenar texto de pruebas: usar cuentas propias, restringir acceso a Redis y eliminar datos cuando corresponda.
- La deduplicación se registra antes de generar o enviar. Ante un envío de resultado incierto NO reintenta automáticamente, para evitar respuestas repetidas. Revisar manualmente los estados received/sending/human_required.
- Máximo cinco eventos por solicitud, procesamiento síncrono y una respuesta por remitente cada 30 segundos. Mensajes rápidos adicionales pasan a revisión manual. Esta versión NO tiene cola durable ni garantía de entrega. Antes del uso general, agregar cola/reintentos controlados, panel de atención humana, monitoreo y políticas de retención/eliminación.
- Mantener BOT_MODE=off para detener respuestas y volver a desplegar. Verificar también envíos en curso.
- El endpoint debe ser accesible a Meta sin el login de Vercel. No exponer secretos para lograrlo.
- Antes de abrir a terceros, completar los requisitos que muestre Meta (permisos, revisión, publicación, privacidad y eliminación de datos). No se ha verificado la elegibilidad ni aprobación de esta app.
- Vigilar vencimiento y renovación de tokens. No se incluye renovación automática.

## Validación realizada

Node.js: node --test. Pruebas de firma válida/alterada, filtrado de eventos, verificación del webhook, rechazo de llamadas sin firma, modo off y deduplicación. Sin llamadas reales a Groq, Meta, Redis ni Vercel. Falta prueba de despliegue y extremo a extremo.

## Referencias oficiales consultadas

- https://developers.facebook.com/documentation/instagram-platform/webhooks/setup
- https://www.postman.com/meta/instagram/documentation/6yqw8pt/instagram-api
- https://vercel.com/docs/functions/functions-api-reference
- https://console.groq.com/docs/api-reference
- https://console.groq.com/docs/your-data
- https://upstash.com/docs/redis/features/restapi

## Cambios 0.2: respuestas contextuales
- Se responde a la pregunta concreta, sin bienvenida fija ni interrogatorio comercial.
- Memoria separada por remitente: hasta 12 mensajes (6 intercambios), con vencimiento a las 24 horas de la última respuesta enviada.
- Solo se guarda como historial conversacional lo que se confirmó enviado; los borradores no se presentan al modelo como respuestas que el seguidor recibió.
- En draft se guarda una simulación separada en ader:draft-conversation:<hash>, hasta 12 mensajes y 24 horas. No se usa en test ni se considera enviada a Instagram. Solo incluye intercambios posteriores a esta actualización. Para reiniciar la simulación, borrar únicamente esa clave del remitente autorizado.
- Claves de conversación: ader:conversation:<hash del remitente>. Para borrar memoria, eliminar esa clave; los registros de eventos tienen retención separada de 7 días.
- Las reglas conservadoras de atención humana siguen activas: ciertas palabras detienen la respuesta automática. No se implementó un clasificador semántico ni panel de derivación.
- Sin audio, sin navegación web y sin recuperación de datos de proyectos. No se incorporaron datos privados de clientes.
- Pruebas locales con servicios simulados; NO verifican calidad del modelo, saldo, permisos de Meta ni entrega real.
- Esta actualización requiere subir el código al proyecto existente. Redeploy del código anterior por sí solo NO instala estos cambios.

## Ajuste de tono y derivación — 19/10
Sin nombre propio ni empleado ficticio. Tono rioplatense breve para DM.
Se conserva una identificación breve de asistencia virtual al comienzo; no se suplanta a Ezequiel.
Un detector local de frases sobre identidad (por ejemplo «¿sos una IA?») pausa al remitente por 24 horas y registra identity_question sin llamar a IA ni enviar respuesta.
El detector usa reglas y no cubre todas las paráfrasis. No hay notificación al teléfono ni traspaso automático de interfaz; Eze debe revisar Instagram. La pausa vence automáticamente y se renueva ante un mensaje recibido durante ella.

## Privacidad y solicitudes de eliminación
Páginas públicas incorporadas: /privacidad.html y /eliminar-datos.html.
Contacto autorizado: ader.studio.arq@gmail.com. No se enviaron correos ni se publicaron estas páginas desde este entorno.
Antes de publicar, el titular debe revisar el texto y asumir la atención del correo.
Procedimiento manual: verificar la cuenta por un intercambio en Instagram, obtener su ID de remitente mediante un evento autorizado y localizar registros ader:message:* cuyo JSON tenga ese sender. Revisar y borrar solo las claves correspondientes. Borrar también draftConversationKey(sender), conversationKey(sender), ader:paused:<sender> y ader:rate:<sender>. Nunca usar FLUSHDB ni borrar registros de otras personas. Mantener apagado el bot durante la operación para evitar nuevas escrituras. Confirmar el resultado al solicitante y revisar las copias técnicas/proveedores que correspondan. El username por sí solo no está guardado: se necesita vincularlo al ID, sin pedir documentos sensibles.
Este paquete no incluye borrado automático ni bandeja de solicitudes. No configurar eliminar-datos.html como callback API: es una página de instrucciones.

## Ajuste 20/10: continuidad del piloto
Draft conserva ahora memoria de simulación separada. No se reconstruyen borradores anteriores ni se aprende automáticamente de correcciones en el chat. Se incorporó el ejemplo autorizado SketchUp → imágenes base → renders, resolver antes de preguntar y no nombrar al titular.

## Revisión de salida 20/10
Antes de guardar o enviar se eliminan ¿, ! y ¡, conservando ?. Se corrigen formas de tuteo observadas con un diccionario local; no es una revisión semántica completa.

## Formato adaptativo 20/10
El prompt adapta la extensión a los mensajes observados. Los párrafos largos se envían juntos; en intercambios breves, los bloques separados por línea en blanco pueden enviarse como mensajes independientes (máximo cuatro por respuesta, resto unido sin perder contenido). Solo se recuerda cada parte confirmada enviada. Se comprueba pausa antes de cada parte. Sigue siendo piloto: no agrupa ráfagas entrantes, mantiene el límite de 30 s y no incorpora todavía demora inicial ni entre envíos. Requiere cola durable para incorporar esas funciones sin prolongar el webhook.

## Cola diferida 20/10 — esta sección reemplaza el límite de 30 s para cuentas autorizadas
Requiere QSTASH_TOKEN y QUEUE_WORKER_TOKEN (secreto aleatorio >=32 caracteres) en Production ANTES de subir. No publicar esta versión sin esas variables: devuelve 503 en lugar de responder instantáneamente. Mantener BOT_MODE=off durante preparación. QStash programa /api/queue-worker con 15 s de demora. Verificar el plan Free y sus cuotas en consola; no se activa ni contrata un plan desde el código.
Cada evento autorizado programa un trabajo. Se agrupa lo acumulado al comenzar el primer trabajo elegible; no es una espera desde el último mensaje. Un bloqueo por remitente serializa la generación y envío. Nuevos mensajes durante el proceso quedan para otro trabajo. Pausa de 1,5 s entre bloques. Demora efectiva = ventana + modelo + red; no se garantiza menos de un minuto ante fallos/reintentos.
El webhook solo persiste y programa, sin esperar la respuesta del modelo. QStash reintenta fallos del worker hasta tres veces. Registros pendientes duran 24 h. Lotes extraídos se conservan como pending:<hash>:inflight:<id> siete días si el proceso se interrumpe, para revisión manual; NO se reenvían automáticamente porque podría duplicarse un envío. Revisar consola QStash/DLQ y Redis tras errores. No hay notificación automática ni recuperación integral de interrupciones. Borrar también pending y queued correspondientes al atender eliminación de datos.
Pruebas simuladas verifican agrupación, autenticación y aislamiento. Falta prueba real QStash → Vercel → Instagram. Nunca usar con toda la comunidad sin completar esa validación.

Configurar QSTASH_URL=https://qstash-eu-central-1.upstash.io para la región EU seleccionada. QUEUE_WORKER_TOKEN debe ser un secreto aleatorio de al menos 32 caracteres, distinto del token QStash. Mantener BOT_MODE=test y la cuenta de prueba durante la validación real.

## Activación pública
BOT_MODE=live permite responder a remitentes fuera de TEST_SENDER_IDS. Guardar antes del despliegue. BOT_MODE=off detiene nuevas respuestas al desplegar esa configuración. El historial v2 arranca vacío al actualizar; cada remitente tiene su propia clave. Un saludo aislado reinicia su historial. La IA recibe solo las últimas tres intervenciones previas del cliente, no respuestas anteriores del bot. Las pausas por revisión humana siguen vigentes; no hay notificación al teléfono. Probar una cuenta externa después de Ready: publicar la app no demuestra por sí solo que Meta autorice los permisos necesarios.

## Base del estudio
lib/knowledge.js contiene las etapas, servicios independientes y herramientas. Los nombres de las cuatro subetapas se verificaron en Casa Ángel; servicios de renders, modelado 3D y documentación fueron autorizados por Eze. Es una base estática: editarla requiere desplegar. Los chats de clientes no modifican esa base.
